from lab1.vacuum import *

DEBUG_OPT_DENSEWORLDMAP = False

AGENT_STATE_UNKNOWN = 0
AGENT_STATE_WALL = 1
AGENT_STATE_CLEAR = 2
AGENT_STATE_DIRT = 3
AGENT_STATE_HOME = 4

AGENT_DIRECTION_NORTH = 0
AGENT_DIRECTION_EAST = 1
AGENT_DIRECTION_SOUTH = 2
AGENT_DIRECTION_WEST = 3

def direction_to_string(cdr):
    cdr %= 4
    return  "NORTH" if cdr == AGENT_DIRECTION_NORTH else\
            "EAST"  if cdr == AGENT_DIRECTION_EAST else\
            "SOUTH" if cdr == AGENT_DIRECTION_SOUTH else\
            "WEST" #if dir == AGENT_DIRECTION_WEST

"""
Internal state of a vacuum agent
"""
class MyAgentState:

    def __init__(self, width, height):

        # Initialize perceived world state
        self.world = [[AGENT_STATE_UNKNOWN for _ in range(height)] for _ in range(width)]
        self.world[1][1] = AGENT_STATE_HOME

        # Agent internal state
        self.last_action = ACTION_NOP
        self.direction = AGENT_DIRECTION_EAST
        self.pos_x = 1
        self.pos_y = 1

        # Metadata
        self.world_width = width
        self.world_height = height
        
        # cells that already been visited
        self.visited = set()

        # current nav target
        self.target = None

        self.planned_path = []

        print(width, height)

    """
    Update perceived agent location
    """
    def update_position(self, bump):
        if not bump and self.last_action == ACTION_FORWARD:
            if self.direction == AGENT_DIRECTION_EAST:
                self.pos_x += 1
            elif self.direction == AGENT_DIRECTION_SOUTH:
                self.pos_y += 1
            elif self.direction == AGENT_DIRECTION_WEST:
                self.pos_x -= 1
            elif self.direction == AGENT_DIRECTION_NORTH:
                self.pos_y -= 1

    """
    Update perceived or inferred information about a part of the world
    """
    def update_world(self, x, y, info):
        self.world[x][y] = info

    """
    Dumps a map of the world as the agent knows it
    """
    def print_world_debug(self):
        for y in range(self.world_height):
            for x in range(self.world_width):
                if self.world[x][y] == AGENT_STATE_UNKNOWN:
                    print("?" if DEBUG_OPT_DENSEWORLDMAP else " ? ", end="")
                elif self.world[x][y] == AGENT_STATE_WALL:
                    print("#" if DEBUG_OPT_DENSEWORLDMAP else " # ", end="")
                elif self.world[x][y] == AGENT_STATE_CLEAR:
                    print("." if DEBUG_OPT_DENSEWORLDMAP else " . ", end="")
                elif self.world[x][y] == AGENT_STATE_DIRT:
                    print("D" if DEBUG_OPT_DENSEWORLDMAP else " D ", end="")
                elif self.world[x][y] == AGENT_STATE_HOME:
                    print("H" if DEBUG_OPT_DENSEWORLDMAP else " H ", end="")

            print() # Newline
        print() # Delimiter post-print

"""
Vacuum agent
"""
class MyVacuumAgent(Agent):

    def __init__(self, world_width, world_height, log):
        super().__init__(self.execute)
        self.initial_random_actions = 10
        self.iteration_counter = world_width * world_height * 4
        self.state = MyAgentState(world_width, world_height)
        self.log = log

        self.returning_home = False
        self.finished = False

    def move_to_random_start_position(self, bump):
        action = random()

        self.initial_random_actions -= 1
        self.state.update_position(bump)

        if action < 0.1666666:   # 1/6 chance
            self.state.direction = (self.state.direction + 3) % 4
            self.state.last_action = ACTION_TURN_LEFT
            return ACTION_TURN_LEFT
        elif action < 0.3333333: # 1/6 chance
            self.state.direction = (self.state.direction + 1) % 4
            self.state.last_action = ACTION_TURN_RIGHT
            return ACTION_TURN_RIGHT
        else:                    # 4/6 chance
            self.state.last_action = ACTION_FORWARD
            return ACTION_FORWARD

    
    def execute(self, percept):

        ###########################
        # DO NOT MODIFY THIS CODE #
        ###########################

        bump = percept.attributes["bump"]
        dirt = percept.attributes["dirt"]
        home = percept.attributes["home"]

        if self.finished:
            return ACTION_NOP

        # Move agent to a randomly chosen initial position
        if self.initial_random_actions > 0:
            self.log("Moving to random start position ({} steps left)".format(self.initial_random_actions))
            return self.move_to_random_start_position(bump)

        # Finalize randomization by properly updating position (without subsequently changing it)
        elif self.initial_random_actions == 0:
            self.initial_random_actions -= 1
            self.state.update_position(bump)
            if home:
                self.state.update_world(
                    self.state.pos_x,
                    self.state.pos_y,
                    AGENT_STATE_HOME
                )
            self.state.last_action = ACTION_SUCK
            self.log("Processing percepts after position randomization")
            return ACTION_SUCK


        ########################
        # START MODIFYING HERE #
        ########################

        # Max iterations for the agent
        if self.iteration_counter < 1:
            if self.iteration_counter == 0:
                self.iteration_counter -= 1
                self.log("Iteration counter is now 0. Halting!")
                self.log("Performance: {}".format(self.performance))
            return ACTION_NOP

        self.log("Position: ({}, {})\t\tDirection: {}".format(self.state.pos_x, self.state.pos_y,
                                                              direction_to_string(self.state.direction)))

        self.iteration_counter -= 1

        # --------------------------
        # 1. Update agent pos
        # --------------------------

        self.state.update_position(bump)
        x = self.state.pos_x
        y = self.state.pos_y

        self.log("Position: ({}, {})\t\tDirection: {}".format(x, y, direction_to_string(self.state.direction)))

        # --------------------------
        # 2. Handle bump / obstacle
        # --------------------------

        if bump:
            offset = [(0, -1), (1, 0), (0, 1), (-1, 0)][self.state.direction]

            wall_x = x + offset[0]
            wall_y = y + offset[1]

            if (
                0 <= wall_x < self.state.world_width and
                0 <= wall_y < self.state.world_height
            ):
                self.state.update_world(wall_x, wall_y, AGENT_STATE_WALL)
                self.log("BUMP! Marking ({}, {}) as a wall.".format(wall_x, wall_y))

            # failed to move forward -> no useful
            self.state.last_action = ACTION_NOP
            # forget old path
            self.state.planned_path = []

        # ---------------------------------
        # 3. Update current tile
        # ---------------------------------

        if dirt:
            self.state.update_world(
                x,
                y,
                AGENT_STATE_DIRT
            )
        else:
            # Do not overwrite HOME
            if self.state.world[x][y] != AGENT_STATE_HOME:
                self.state.update_world(
                    x,
                    y,
                    AGENT_STATE_CLEAR
                )

        # Mark current cell as visited
        self.state.visited.add((x, y))

        # ---------------------------------
        # 4. Clean dirt
        # ---------------------------------

        if dirt:
            self.log("DIRT -> choosing SUCK action!")
            self.state.last_action = ACTION_SUCK
            return ACTION_SUCK

        # ---------------------------------
        # 5. Look for an unexplored cell
        # ---------------------------------

        directions = [
            AGENT_DIRECTION_NORTH,
            AGENT_DIRECTION_EAST,
            AGENT_DIRECTION_SOUTH,
            AGENT_DIRECTION_WEST
        ]

        offsets = {
            AGENT_DIRECTION_NORTH: (0, -1),
            AGENT_DIRECTION_EAST:  (1, 0),
            AGENT_DIRECTION_SOUTH: (0, 1),
            AGENT_DIRECTION_WEST:  (-1, 0)
        }

        unknown_neighbors = []

        for direction in directions:

            nx = x + offsets[direction][0]
            ny = y + offsets[direction][1]

            if (
                0 <= nx < self.state.world_width
                and 0 <= ny < self.state.world_height
            ):
                if self.state.world[nx][ny] == AGENT_STATE_UNKNOWN:
                    unknown_neighbors.append(direction)

        # ---------------------------------
        # 6. Explore unknown neighbor
        # ---------------------------------

        if unknown_neighbors:

            # Prefer continuing in the same direction
            if self.state.direction in unknown_neighbors:
                desired_direction = self.state.direction
            else:
                desired_direction = unknown_neighbors[0]

            # Turn toward the desired direction
            if self.state.direction != desired_direction:

                diff = (
                    desired_direction - self.state.direction
                ) % 4

                if diff == 1:
                    self.state.direction = (
                        self.state.direction + 1
                    ) % 4

                    self.state.last_action = ACTION_TURN_RIGHT
                    return ACTION_TURN_RIGHT

                elif diff == 3:
                    self.state.direction = (
                        self.state.direction + 3
                    ) % 4

                    self.state.last_action = ACTION_TURN_LEFT
                    return ACTION_TURN_LEFT

                else:
                    # 180-degree turn
                    self.state.direction = (
                        self.state.direction + 1
                    ) % 4

                    self.state.last_action = ACTION_TURN_RIGHT
                    return ACTION_TURN_RIGHT

            # Direction is correct -> move forward
            self.state.last_action = ACTION_FORWARD
            return ACTION_FORWARD

        # ---------------------------------
        # 7. No unknown neighbor
        # ---------------------------------

        # Find a path to the nearest known cell
        # that has an unknown neighbor.
        path, frontier_direction = self.find_path_to_frontier()

        if path is not None:

            # If we are already at the frontier,
            # move toward the unknown cell.
            if len(path) == 0:
                desired_direction = frontier_direction

            else:
                # Follow the first step of the BFS path.
                desired_direction = path[0]

            # Turn toward the desired direction
            if self.state.direction != desired_direction:

                diff = (
                    desired_direction - self.state.direction
                ) % 4

                if diff == 1:
                    self.state.direction = (
                        self.state.direction + 1
                    ) % 4

                    self.state.last_action = ACTION_TURN_RIGHT
                    return ACTION_TURN_RIGHT

                elif diff == 3:
                    self.state.direction = (
                        self.state.direction + 3
                    ) % 4

                    self.state.last_action = ACTION_TURN_LEFT
                    return ACTION_TURN_LEFT

                else:
                    # 180-degree turn
                    self.state.direction = (
                        self.state.direction + 1
                    ) % 4

                    self.state.last_action = ACTION_TURN_RIGHT
                    return ACTION_TURN_RIGHT

            # Direction is correct -> move
            self.state.last_action = ACTION_FORWARD
            return ACTION_FORWARD

        # ---------------------------------
        # 8. No more unexplored reachable cells
        # ---------------------------------

        self.log("No unexplored reachable cells remain.")

        # Start returning to home
        self.returning_home = True

        # If already at home, stop
        if home:
            self.log("Returned to home. Halting!")
            self.finished = True
            self.state.last_action = ACTION_NOP
            return ACTION_NOP

        # Find a path back to home
        path = self.find_path_to_home()

        if path:
            desired_direction = path[0]

            # Turn toward the next step
            if self.state.direction != desired_direction:

                diff = (
                    desired_direction - self.state.direction
                ) % 4

                if diff == 1:
                    self.state.direction = (
                        self.state.direction + 1
                    ) % 4

                    self.state.last_action = ACTION_TURN_RIGHT
                    return ACTION_TURN_RIGHT

                elif diff == 3:
                    self.state.direction = (
                        self.state.direction + 3
                    ) % 4

                    self.state.last_action = ACTION_TURN_LEFT
                    return ACTION_TURN_LEFT

                else:
                    # 180-degree turn
                    self.state.direction = (
                        self.state.direction + 1
                    ) % 4

                    self.state.last_action = ACTION_TURN_RIGHT
                    return ACTION_TURN_RIGHT

            # Direction is correct -> move toward home
            self.state.last_action = ACTION_FORWARD
            return ACTION_FORWARD

        # Should normally never happen if home is reachable
        self.log("Could not find a path to home.")
        self.state.last_action = ACTION_NOP
        return ACTION_NOP

    def find_path_to_frontier(self):
        from collections import deque

        start = (
            self.state.pos_x,
            self.state.pos_y
        )

        queue = deque()
        queue.append((start, []))

        visited = set()
        visited.add(start)

        directions = [
            AGENT_DIRECTION_NORTH,
            AGENT_DIRECTION_EAST,
            AGENT_DIRECTION_SOUTH,
            AGENT_DIRECTION_WEST
        ]

        offsets = {
            AGENT_DIRECTION_NORTH: (0, -1),
            AGENT_DIRECTION_EAST:  (1, 0),
            AGENT_DIRECTION_SOUTH: (0, 1),
            AGENT_DIRECTION_WEST:  (-1, 0)
        }

        while queue:

            (x, y), path = queue.popleft()

            # Check whether this cell has an unknown neighbor
            for direction in directions:

                nx = x + offsets[direction][0]
                ny = y + offsets[direction][1]

                if (
                    0 <= nx < self.state.world_width
                    and 0 <= ny < self.state.world_height
                    and self.state.world[nx][ny] == AGENT_STATE_UNKNOWN
                ):
                    # Found a frontier.
                    # path = route from current position to this frontier.
                    # direction = direction toward the unknown cell.
                    return path, direction

            # Continue BFS through known traversable cells
            for direction in directions:

                nx = x + offsets[direction][0]
                ny = y + offsets[direction][1]

                if not (
                    0 <= nx < self.state.world_width
                    and 0 <= ny < self.state.world_height
                ):
                    continue

                if (nx, ny) in visited:
                    continue

                cell = self.state.world[nx][ny]

                if cell in (
                    AGENT_STATE_CLEAR,
                    AGENT_STATE_DIRT,
                    AGENT_STATE_HOME
                ):
                    visited.add((nx, ny))

                    queue.append(
                        (
                            (nx, ny),
                            path + [direction]
                        )
                    )

        # No frontier exists
        return None, None
    
    def find_path_to_home(self):
        from collections import deque

        start = (
            self.state.pos_x,
            self.state.pos_y
        )

        goal = (1, 1)

        # Already at home
        if start == goal:
            return []

        queue = deque()
        queue.append((start, []))

        visited = set()
        visited.add(start)

        directions = [
            AGENT_DIRECTION_NORTH,
            AGENT_DIRECTION_EAST,
            AGENT_DIRECTION_SOUTH,
            AGENT_DIRECTION_WEST
        ]

        offsets = {
            AGENT_DIRECTION_NORTH: (0, -1),
            AGENT_DIRECTION_EAST:  (1, 0),
            AGENT_DIRECTION_SOUTH: (0, 1),
            AGENT_DIRECTION_WEST:  (-1, 0)
        }

        while queue:

            (x, y), path = queue.popleft()

            for direction in directions:

                nx = x + offsets[direction][0]
                ny = y + offsets[direction][1]

                if not (
                    0 <= nx < self.state.world_width
                    and 0 <= ny < self.state.world_height
                ):
                    continue

                if (nx, ny) in visited:
                    continue

                # Found home
                if (nx, ny) == goal:
                    return path + [direction]

                cell = self.state.world[nx][ny]

                # Only move through known traversable cells
                if cell in (
                    AGENT_STATE_CLEAR,
                    AGENT_STATE_DIRT,
                    AGENT_STATE_HOME
                ):
                    visited.add((nx, ny))

                    queue.append(
                        (
                            (nx, ny),
                            path + [direction]
                        )
                    )

        return None